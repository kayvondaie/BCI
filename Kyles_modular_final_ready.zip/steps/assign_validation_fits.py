def run():
    # Cell 45
import copy
valid_full_fits = copy.deepcopy(full_fits)
print('Fit assigned as validation.')

if __name__ == '__main__':
    run()
